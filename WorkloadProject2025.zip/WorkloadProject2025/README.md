This is Group 01's readme file. The purpose of this file is to document changes or suggestions to the project and to inform the group of such.  --Sean made this text
