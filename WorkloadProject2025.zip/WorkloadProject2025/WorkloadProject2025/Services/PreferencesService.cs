using Microsoft.JSInterop;

namespace WorkloadProject2025.Services;

public class PreferencesService
{
    private readonly IJSRuntime _jsRuntime;
    private static readonly HashSet<string> SupportedLanguages = new() { "en", "fr", "es" };
    
    public event Action? OnChange;
    
    public bool IsDarkMode { get; private set; }
    public bool IsHighContrast { get; private set; }
    public string Language { get; private set; } = "en";
    
    public PreferencesService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }
    
    public async Task InitializeAsync()
    {
        IsDarkMode = await GetPreferenceAsync("darkMode", false);
        IsHighContrast = await GetPreferenceAsync("highContrast", false);
        Language = await GetPreferenceAsync("language", "en");
    }
    
    public async Task SetDarkModeAsync(bool isDarkMode)
    {
        IsDarkMode = isDarkMode;
        await SetPreferenceAsync("darkMode", isDarkMode);
        NotifyStateChanged();
    }
    
    public async Task SetHighContrastAsync(bool isHighContrast)
    {
        IsHighContrast = isHighContrast;
        await SetPreferenceAsync("highContrast", isHighContrast);
        NotifyStateChanged();
    }
    
    public async Task SetLanguageAsync(string language)
    {
        // Validate language code
        if (string.IsNullOrWhiteSpace(language))
        {
            throw new ArgumentException("Language code cannot be null or empty.", nameof(language));
        }
        
        if (!SupportedLanguages.Contains(language))
        {
            throw new ArgumentException($"Unsupported language code: {language}. Supported languages are: {string.Join(", ", SupportedLanguages)}.", nameof(language));
        }
        
        Language = language;
        await SetPreferenceAsync("language", language);
        NotifyStateChanged();
    }
    
    private async Task<T> GetPreferenceAsync<T>(string key, T defaultValue)
    {
        try
        {
            var value = await _jsRuntime.InvokeAsync<string>("localStorage.getItem", key);
            if (string.IsNullOrEmpty(value))
                return defaultValue;
            
            if (typeof(T) == typeof(bool))
                return (T)(object)bool.Parse(value);
            
            return (T)(object)value;
        }
        catch
        {
            return defaultValue;
        }
    }
    
    private async Task SetPreferenceAsync<T>(string key, T value)
    {
        try
        {
            await _jsRuntime.InvokeVoidAsync("localStorage.setItem", key, value?.ToString() ?? "");
        }
        catch
        {
            // Silently fail if localStorage is not available
        }
    }
    
    private void NotifyStateChanged() => OnChange?.Invoke();
}
